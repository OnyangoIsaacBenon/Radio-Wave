package com.example.mainactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class HomeActivity extends AppCompatActivity {

    WebView radio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        radio = (WebView) findViewById(R.id.web);

        WebSettings ws = radio.getSettings();
        ws.setJavaScriptEnabled(true);
        radio.loadUrl("https://megafm.co.ug/listen-to-mega-fm-stations-live/");
        radio.setWebViewClient(new WebViewClient());



    }

    @Override
    public void onBackPressed(){
    if(radio.canGoBack()){
        radio.goBack();
    }
    else{
        super.onBackPressed();
    }
    }

}