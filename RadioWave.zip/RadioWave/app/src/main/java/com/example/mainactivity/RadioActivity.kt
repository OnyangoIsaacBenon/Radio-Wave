package com.example.mainactivity

import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {
    var radio: WebView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        radio = findViewById<View>(R.id.web) as WebView
        val ws = radio!!.settings
        ws.javaScriptEnabled = true
        radio!!.loadUrl("https://megafm.co.ug/listen-to-mega-fm-stations-live/")
        radio!!.webViewClient = WebViewClient()
    }

    override fun onBackPressed() {
        if (radio!!.canGoBack()) {
            radio!!.goBack()
        } else {
            super.onBackPressed()
        }
    }
}